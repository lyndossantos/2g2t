# Estudo segundo Trimestre
## Tema da Sala: Filmes (Cinama)
Nome: Emilyn - N 10
